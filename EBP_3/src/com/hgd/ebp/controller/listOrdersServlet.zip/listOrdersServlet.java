package com.hgd.ebp.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.hgd.ebp.service.orders_servers;
import com.hgd.ebp.domain.Orders;
import com.hgd.ebp.domain.OrderList;
import com.hgd.ebp.service.orderlist_servers;

@SuppressWarnings("serial")
//@WebServlet("/listOrdersServlet")
public class listOrdersServlet extends HttpServlet {
//	public void doGet(HttpServletRequest request, HttpServletResponse response)
//			throws ServletException, IOException {
//		orders_servers OrdersSvc = orders_servers.getInstance();
//		try {
//			System.out.println("ready getAllorders...");
//			List<Orders> list = OrdersSvc.getAllOrders();
//			request.setAttribute("listOrders", list);  
//			System.out.println("get done...");
//		} catch (Exception e) {
//			e.printStackTrace();
//		}
//		System.out.println("accept");
//        //������������ת��JSP���׳�ת��JSP
//        RequestDispatcher rd = request.getRequestDispatcher("./order_admin.jsp");
//        rd.forward(request, response);
//	}
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}
	
	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		orders_servers searchtime = orders_servers.getInstance();
		orderlist_servers os=orderlist_servers.getInstance();
		String bdate = request.getParameter("bdate");
		String edate = request.getParameter("edate");
		try{
			if (request.getParameter("bdate") != null) {
			bdate += " 00:00:00";
			edate += " 23:59:59";
			System.out.println(2);
			List<Orders> list = searchtime.SearchTime(bdate, edate);
			List<OrderList> list_2=os.getAllOrders();
			if (list == null) System.out.println(1);
			for (Orders o : list) {
				System.out.println(o.getOid());
			}
			System.out.println("============="+list);
			request.setAttribute("listOrders", list);
			request.getRequestDispatcher("./order_admin.jsp").forward(request, response);
			} 			

			List<Orders> list = searchtime.getAllOrders();
			request.setAttribute("listOrders", list);
			request.getRequestDispatcher("./order_admin.jsp").forward(request, response);
		}catch(Exception e){
			e.printStackTrace();
		}
		

	}
}