package com.hgd.ebp.domain;

import java.sql.Date;
import java.sql.Timestamp;

public class Orders {
	private int oid;
	private Timestamp commitTime;
	private double amount;
	private int uid;
	
	public Orders(int oid ,Timestamp commitTime2,double amount,int uid){
		this.oid=oid;
		this.commitTime=commitTime2;
		this.amount=amount;
		this.uid=uid;
	}
	public int getOid() {
		return oid;
	}
	public void setOid(int oid) {
		this.oid = oid;
	}
	public  Timestamp getCommitTime() {
		return commitTime;
	}
	public void setCommitTime(Timestamp commitTime) {
		this.commitTime = commitTime;
	}
	public double getAmount() {
		return amount;
	}
	public void setAmount(double amount) {
		this.amount = amount;
	}
	public int getUid() {
		return uid;
	}
	public void setUid(int uid) {
		this.uid = uid;
	}
}
