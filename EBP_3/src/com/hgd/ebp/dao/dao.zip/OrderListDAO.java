package com.hgd.ebp.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import com.hgd.ebp.domain.OrderList;


public class OrderListDAO {
	private static final String SELECT_ALL="Select *from orderlist";
	
	private static OrderListDAO dao = new OrderListDAO();
	private DataSource ds;
	
	private OrderListDAO() {
		try {
			Context ctx = new InitialContext();   //1 ��ȡJNDI
			ds = (DataSource)ctx.lookup("java:comp/env/jdbc/ebp");   //2 ��JNDI����DS
		} catch (NamingException e) {
			e.printStackTrace();
		}
	}
	
	public static OrderListDAO getInstance() {
		return dao;
	}
	
	
	public List<OrderList> queryAll() throws Exception {
		Connection connection = null;
        PreparedStatement stmt = null;
        ResultSet results = null;

        List<OrderList> list = new ArrayList<OrderList>();
        try {
            connection = ds.getConnection();   //step3 �����ӳ���ȡ������            
            stmt = connection.prepareStatement(SELECT_ALL);           
            results = stmt.executeQuery();         
            
            while (results.next()) {
                int lid = results.getInt(1);
                String desc = results.getString(2);
                double price = results.getDouble(3);
                int quantity = results.getInt(4);
               Double amount = results.getDouble(5);
                int oid = results.getInt(6);
        
                OrderList orderlist = new OrderList(lid,desc,price,quantity,amount,oid);
                list.add(orderlist);
               
            }
            
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            if (results != null) {
                try { results.close(); } catch (SQLException e) {}
            }
            if (stmt != null) {
                try { stmt.close(); } catch (SQLException e) {}
            }
            if (connection != null) {
                try { connection.close(); } catch (SQLException e) {}  //step4 �黹����
            }
        }
       
        return list;
	}
	
	
	
	
//	public List<OrderList> select_time(String bdate,String edate ) throws Exception{
//		Connection connection = null;
//        PreparedStatement stmt = null;
//        ResultSet rs = null;
//       
//        List<OrderList> list = new ArrayList<OrderList>();
//        
//        try{
//        	connection = ds.getConnection();   //step3 �����ӳ���ȡ������            
//            stmt = connection.prepareStatement(SELECT_ALL);           
//            rs = stmt.executeQuery();    
//            
//            while (rs.next()) {
//            	
//            	Timestamp timestamp = rs.getTimestamp(2);
//            	Timestamp btime = Timestamp.valueOf(bdate);
//            	Timestamp etime = Timestamp.valueOf(edate);
//            	
//            	long bs = btime.getTime();
//            	long es = etime.getTime();
//            	long t = timestamp.getTime();
//            	System.out.println("asdjkhdajkadsjkh");
//            	if(t>=bs && t<=es){ 
//            		int lid = rs.getInt(1);
//                    String desc = rs.getString(2);
//                    double price = rs.getDouble(3);
//                    int quantity = rs.getInt(4);
//                   Double amount = rs.getDouble(5);
//                    int oid = rs.getInt(6);
//            		
//            		OrderList orderslist = new OrderList(lid,desc,price,quantity,amount,oid);
//            		list.add(orderslist);
//            		System.out.println("======"+orderslist.getOid());
//            	}
//            }
//
//        }catch (SQLException e) {
//            e.printStackTrace();
//        } finally {
//            if (rs != null) {
//                try { rs.close(); } catch (SQLException e) {}
//            }
//            if (stmt != null) {
//                try { stmt.close(); } catch (SQLException e) {}
//            }
//            if (connection != null) {
//                try { connection.close(); } catch (SQLException e) {}  //step4 �黹����
//            }
//        }
//       
//        return list;
//	}
}
