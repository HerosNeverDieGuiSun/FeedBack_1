package com.hgd.ebp.dao;

public class TicketDAO {

}
