package com.hgd.ebp.dao;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import com.hgd.ebp.domain.Orders;
public class OrdersDAO {
	private static final String SELECT_ALL="Select *from orders";
	
	private static OrdersDAO dao = new OrdersDAO();
	private DataSource ds;
	
	private OrdersDAO() {
		try {
			Context ctx = new InitialContext();   //1 ��ȡJNDI
			ds = (DataSource)ctx.lookup("java:comp/env/jdbc/ebp");   //2 ��JNDI����DS
		} catch (NamingException e) {
			e.printStackTrace();
		}
	}
	
	public static OrdersDAO getInstance() {
		return dao;
	}
	
	
	public List<Orders> queryAll() throws Exception {
		Connection connection = null;
        PreparedStatement stmt = null;
        ResultSet results = null;

        List<Orders> list = new ArrayList<Orders>();
        try {
            connection = ds.getConnection();   //step3 �����ӳ���ȡ������            
            stmt = connection.prepareStatement(SELECT_ALL);           
            results = stmt.executeQuery();         
            
            while (results.next()) {
                int oid = results.getInt(1);
                Timestamp commitTime = results.getTimestamp(2);
                double amount = results.getDouble(3);
                int uid = results.getInt(4);
        
                Orders orders = new Orders(oid,commitTime,amount,uid);
                list.add(orders);
               
            }
            
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            if (results != null) {
                try { results.close(); } catch (SQLException e) {}
            }
            if (stmt != null) {
                try { stmt.close(); } catch (SQLException e) {}
            }
            if (connection != null) {
                try { connection.close(); } catch (SQLException e) {}  //step4 �黹����
            }
        }
       
        return list;
	}
	public List<Orders> select_time(String bdate,String edate ) throws Exception{
		Connection connection = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
       
        List<Orders> list = new ArrayList<Orders>();
        
        try{
        	connection = ds.getConnection();   //step3 �����ӳ���ȡ������            
            stmt = connection.prepareStatement(SELECT_ALL);           
            rs = stmt.executeQuery();    
            
            while (rs.next()) {
            	
            	Timestamp timestamp = rs.getTimestamp(2);
            	Timestamp btime = Timestamp.valueOf(bdate);
            	Timestamp etime = Timestamp.valueOf(edate);
            	
            	long bs = btime.getTime();
            	long es = etime.getTime();
            	long t = timestamp.getTime();
            	System.out.println("asdjkhdajkadsjkh");
            	if(t>=bs && t<=es){ 
            		int oid = rs.getInt(1);
            		Timestamp commitTime = rs.getTimestamp(2);
            		double amount = rs.getDouble(3);
            		int uid = rs.getInt(4);
            		
            		Orders orders = new Orders(oid,commitTime,amount,uid);
            		list.add(orders);
            		System.out.println("======"+orders.getOid());
            	}
            }

        }catch (SQLException e) {
            e.printStackTrace();
        } finally {
            if (rs != null) {
                try { rs.close(); } catch (SQLException e) {}
            }
            if (stmt != null) {
                try { stmt.close(); } catch (SQLException e) {}
            }
            if (connection != null) {
                try { connection.close(); } catch (SQLException e) {}  //step4 �黹����
            }
        }
       
        return list;
	}
}
