package com.hgd.ebp.service;


import com.hgd.ebp.dao.OrdersDAO;
import com.hgd.ebp.domain.Orders;


import java.util.*;

public class orders_servers {
	private static orders_servers ordersSvc = new orders_servers();
	private OrdersDAO ordersDAO;
	
	private orders_servers() {
		ordersDAO = OrdersDAO.getInstance();
	}
	
	public static orders_servers getInstance() {
	     return ordersSvc;
	}
	
	public List<Orders> getAllOrders() throws Exception {	
		List<Orders> list = ordersDAO.queryAll();
        return list;
	}
	public  List<Orders> SearchTime(String dtime ,String etime)throws Exception{
		
		System.out.println("sssssssss");
		List<Orders> list = ordersDAO.select_time(dtime, etime);
		return list;
		//return OrdersDAO.select_time(dtime,etime);
	}
	
	/*public League addLeague(int year, String season, String title) throws LeagueException {
		return leagueDAO.insert(year, season, title);
	}*/
}
