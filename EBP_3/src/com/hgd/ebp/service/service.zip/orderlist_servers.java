package com.hgd.ebp.service;

import java.util.List;

import com.hgd.ebp.dao.OrderListDAO;
import com.hgd.ebp.domain.OrderList;

public class orderlist_servers {
	private static orderlist_servers orderlistSvc = new orderlist_servers();
	private OrderListDAO orderlistDAO;
	
	private orderlist_servers() {
		orderlistDAO = OrderListDAO.getInstance();
	}
	
	public static orderlist_servers getInstance() {
	     return orderlistSvc;
	}
	
	public List<OrderList> getAllOrders() throws Exception {	
		List<OrderList> list = orderlistDAO.queryAll();
        return list;
	}
//	public  List<OrderList> SearchTime(String dtime ,String etime)throws Exception{
//		
//		System.out.println("sssssssss");
//		List<OrderList> list = orderlistDAO.select_time(dtime, etime);
//		return list;
//		//return OrdersDAO.select_time(dtime,etime);
//	}
}
